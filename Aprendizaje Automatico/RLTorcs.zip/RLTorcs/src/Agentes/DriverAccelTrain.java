package Agentes;

import QLearning.EnvAccel;
import QLearning.LocalQLearningUtils;
import QLearning.Politica;
import QLearning.QLearning;
import champ2011client.SensorModel;

public class DriverAccelTrain extends AbstractTrainDriverBase {

	public DriverAccelTrain() {
		nMaxEpisodios = 250;
		System.out.println(LocalQLearningUtils.GREEN + "Iniciando DriverAccelTrain..." + LocalQLearningUtils.RESET);
		this.env = new EnvAccel();
		this.agent = new QLearning(env);
		this.pol = new Politica(env);
		agent.loadQTableCSV();// Cargamos para volver a entrenar y ajustar mas
		System.out.println("Entrenamiento configurado: " + env.getName());

		System.out.println(agent);
		startTrain();
	}

	@Override
	public float getAccel(SensorModel sensors) {
	
	return env.getActionFromMap(this.currentLearnedAction)[0];
		
	}

}
