package si2024.kevinjesusbandaalu.p01.reglas;

import si2024.kevinjesusbandaalu.common.ICondicion;
import si2024.kevinjesusbandaalu.common.IMundo;
import si2024.kevinjesusbandaalu.p01.Mundo18;

public class Cazar_Condicion implements ICondicion {

	@Override
	public boolean seCumple(IMundo m) {

		
		return true;
	}

}
