package si2024.kevinjesusbandaalu.common;

import core.game.StateObservation;
import ontology.Types.ACTIONS;

public interface IMundo {

	//Representacion del mundo
	public void AnalizarEntorno(StateObservation stateObs);
	
}
