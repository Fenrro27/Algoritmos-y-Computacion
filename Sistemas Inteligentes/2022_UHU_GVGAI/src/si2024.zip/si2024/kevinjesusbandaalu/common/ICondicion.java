package si2024.kevinjesusbandaalu.common;

import ontology.Types.ACTIONS;

public interface ICondicion {

	public boolean seCumple(IMundo m);
	
}
