package si2026.kevinjesusbandaalu.p02;

import ontology.Types.ACTIONS;
import si2026.kevinjesusbandaalu.common.IMundo;
import si2026.kevinjesusbandaalu.common.arbolDecision.ArbolDecision;
import si2026.kevinjesusbandaalu.common.arbolDecision.NodoAccion;
import si2026.kevinjesusbandaalu.common.arbolDecision.NodoDecision;
import si2026.kevinjesusbandaalu.p02.nodos.*;


public class Motor83 extends ArbolDecision{
	
	public Motor83() {
		NodoAccion esperar = new NodoAccion(new Esperar_Accion());
		NodoAccion subir = new NodoAccion(new IrSuperficie_Accion());
        NodoAccion cazar = new NodoAccion(new CazarBuzo_Accion());
        
        NodoAccion patrullar = new NodoAccion(new Patrullar_Accion());
        // Nuevas acciones de defensa
        NodoAccion defenderUso = new NodoAccion(new DefenderUso_Accion());
        NodoAccion defenderHorizontal = new NodoAccion(new DefenderHorizontal_Accion());
        NodoAccion defenderVertical = new NodoAccion(new DefenderVertical_Accion());
        
        // Estructura de decisiones Disparo Dinamico
        NodoAccion encararYDispararVertical = new NodoAccion(new EncararYDispararVertical_Accion());
        NodoAccion encararYDispararHorizontal = new NodoAccion(new EncararYDispararHorizontal_Accion());
        NodoAccion disparoDefecto = new NodoAccion(new DisparoPorDefecto_Accion());
        
        NodoDecision decEnemigoHorizontal = new NodoDecision(new EnemigoAlineadoHorizontal_Condicion(), encararYDispararHorizontal, disparoDefecto);
        NodoDecision decDisparoDinamico = new NodoDecision(new EnemigoAlineadoVertical_Condicion(), encararYDispararVertical, decEnemigoHorizontal);
        
        // Cadena de decisiones base (Tareas y Recolección)
        NodoDecision decSobreSpawn = new NodoDecision(new SobreSpawn_Condicion(), decDisparoDinamico, patrullar);
        NodoDecision decBuzo = new NodoDecision(new HayBuzo_Condicion(), cazar, decSobreSpawn);
        NodoDecision decBolsa = new NodoDecision(new BolsaLlena_Condicion(), subir, decBuzo);
        
        // Decisiones de Mantenimiento (Oxígeno y Superficie)
        NodoDecision decZonaSegura = new NodoDecision(new EnZonaSegura_Condicion(), decDisparoDinamico, esperar);
        NodoDecision decRecarga = new NodoDecision(new EnSuperficie_Condicion(), decZonaSegura, decBolsa);
        NodoDecision decOxigeno = new NodoDecision(new OxigenoBajo_Condicion(), subir, decRecarga);
        
        // Cadena de decisiones de DEFENSA (MÁXIMA PRIORIDAD)
        // Evita morir ahogado pero, más importante, evita chocar al subir a por aire.
        NodoDecision decPeligroVertical = new NodoDecision(new PeligroCercano_Condicion(), defenderVertical, decOxigeno);
        NodoDecision decPeligroHorizontal = new NodoDecision(new PeligroMismaFila_Condicion(), defenderHorizontal, decPeligroVertical);
        this.raiz = new NodoDecision(new PeligroAlineado_Condicion(), defenderUso, decPeligroHorizontal);
        
        
		/**
		 * ESTRATEGIA DE DECISIÓN - MUNDO 83 (SEAQUEST)
		 * -------------------------------------------
		 * * 1. PRIORIDAD CRÍTICA: OXÍGENO / SUPERVIVENCIA
			 * - Si (Oxigeno < MargenSeguridad):
				 * - Si (EnSuperficie): Esperar/Recargar y alinear con enemigos para disparar.
				 * - Sino: ACTION_UP (Emerger).
		 * * 2. SEGURIDAD INMEDIATA: DEFENSA (Revisar)
			 * - Si (Enemigo o Proyectil en trayectoria):
			 * - Si (Alineado y cooldown OK): ACTION_USE (Disparar).
			 * - Sino: ACTION_UP/DOWN (Esquiva vertical).
		 * * 3. GESTIÓN DE RECURSOS: ENTREGA
		 * - Si (BolsaLlena):
		 	* - Ir a superficie para descargar buzos.
		 * * 4. OBJETIVO: CAZA DE BUZOS
		 * - Si (Tengo Objetivo en Memoria):
		 * - Si (Objetivo sigue existiendo): Ir hacia él.
		 * - Sino: Borrar memoria.
		 * - Sino (No tengo objetivo):
		 * - Si (Hay buzos visibles): Elegir uno (Aleatorio o el más cercano) y guardar en memoria.
		 * - Sino: Ir a posición de Spawn de buzos (Patrulla).
		 * * 5. ESTADO POR DEFECTO:
		 * - Mantenerse en el carril central y disparar proactivamente.
		 */
		
	}

}
